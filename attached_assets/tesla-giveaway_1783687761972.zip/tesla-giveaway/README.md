# ⚡ Tesla Car Giveaway - Full Stack Application

A complete, fully functional Tesla-inspired giveaway website with dark theme, premium animations, and full backend integration.

## 🚀 Features

### Pages
- **Homepage** — Immersive Tesla-branded landing page with countdown timer, vehicle showcase, parallax effects, testimonials, and FAQ
- **Entry Page** — Registration form with email/phone validation and country code selector
- **Congratulations Page** — Confetti celebration with email verification instructions
- **Dashboard** — Protected area with car selection (Model 3, Y, S, X, Cybertruck, Roadster), delivery form, and order confirmation
- **Track Order Page** — Interactive tracking with progress bar, timeline, and Leaflet.js map with animated delivery route

### Backend
- Express.js REST API
- Nodemailer email integration (sends from techledger10@gmail.com)
- Tesla-branded HTML email templates
- Token-based session management
- In-memory data storage

### Design
- Tesla-inspired dark theme (#000000)
- Red accent colors (#E82127)
- Glass morphism cards
- Smooth animations and micro-interactions
- Fully responsive (mobile-first)
- Countdown timer with urgency elements
- Parallax scrolling sections

## 📦 Tech Stack

- **Frontend**: HTML5, CSS3, Tailwind CSS, Vanilla JavaScript
- **Backend**: Node.js, Express.js
- **Map**: Leaflet.js (dark theme)
- **Email**: Nodemailer + Gmail SMTP
- **Icons/Images**: Tesla official digital assets

## 🔧 Setup

```bash
cd tesla-giveaway/server
npm install
node index.js
```

Server starts on `http://localhost:3001`

## 📧 Email Configuration

The application uses `techledger10@gmail.com` with Gmail App Password for SMTP authentication.

## 🌐 Routes

| Route | Description |
|-------|-------------|
| `/` | Homepage |
| `/entry.html` | Giveaway entry form |
| `/congratulations.html` | Post-entry success page |
| `/dashboard.html?session=TOKEN` | Protected dashboard |
| `/track.html` | Order tracking |
| `/verify-error.html` | Verification failure page |

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/entry` | Submit giveaway entry |
| GET | `/api/verify` | Verify email (redirects) |
| GET | `/api/session` | Validate session token |
| POST | `/api/order` | Place delivery order |
| GET | `/api/order/:id` | Track order by ID |
| GET | `/api/order/tracking/:num` | Track by tracking number |
