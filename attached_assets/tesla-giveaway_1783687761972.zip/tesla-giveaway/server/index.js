const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
const path = require('path');
app.use(express.static(path.join(__dirname, '..', 'public')));

// In-memory storage (in production, use a database)
const entries = {};
const verifiedUsers = {};
const orders = {};

// Email transporter using techledger10@gmail.com
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'techledger10@gmail.com',
    pass: 'kkpy bzvy xyhk vljr'
  }
});

console.log('⚡ Email transporter configured');

// ============ API ROUTES ============

// POST /api/entry - Submit giveaway entry
app.post('/api/entry', async (req, res) => {
  try {
    const { email, phone, firstName, lastName } = req.body;

    // Validate
    if (!email || !phone) {
      return res.status(400).json({ error: 'Email and phone number are required.' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }

    // Check duplicate entry
    if (entries[email.toLowerCase()]) {
      return res.status(409).json({ error: 'This email has already been entered. Only one entry per person is allowed.' });
    }

    // Generate verification token
    const verificationToken = crypto.randomBytes(32).toString('hex');
    const entryId = uuidv4();

    // Store entry
    entries[email.toLowerCase()] = {
      id: entryId,
      email: email.toLowerCase(),
      phone,
      firstName: firstName || '',
      lastName: lastName || '',
      verificationToken,
      verified: false,
      createdAt: new Date().toISOString()
    };

    // Generate verification link
    const baseUrl = process.env.BASE_URL || `https://localhost:${PORT}`;
    const verifyLink = `${baseUrl}/verify?token=${verificationToken}&email=${encodeURIComponent(email.toLowerCase())}`;

    // Send verification email
    const mailOptions = {
      from: '"Tesla Giveaway" <techledger10@gmail.com>',
      to: email,
      subject: '⚡ Verify Your Email - Tesla Giveaway Entry',
      html: getVerificationEmailTemplate(firstName || 'there', verifyLink, entryId)
    };

    await transporter.sendMail(mailOptions);
    console.log(`✅ Verification email sent to ${email}`);

    res.json({
      success: true,
      message: 'Entry submitted! Please check your email to verify.',
      entryId
    });

  } catch (error) {
    console.error('Entry error:', error);
    res.status(500).json({ error: 'Server error. Please try again.' });
  }
});

// GET /api/verify - Verify email
app.get('/api/verify', (req, res) => {
  const { token, email } = req.query;

  if (!token || !email) {
    return res.redirect(`/verify-error.html?reason=invalid`);
  }

  const entry = entries[email.toLowerCase()];
  if (!entry) {
    return res.redirect(`/verify-error.html?reason=notfound`);
  }

  if (entry.verificationToken !== token) {
    return res.redirect(`/verify-error.html?reason=invalid_token`);
  }

  // Mark as verified
  entry.verified = true;
  const sessionToken = crypto.randomBytes(32).toString('hex');
  verifiedUsers[sessionToken] = {
    email: email.toLowerCase(),
    entryId: entry.id,
    verifiedAt: new Date().toISOString()
  };

  // Redirect to dashboard with session token
  res.redirect(`/dashboard.html?session=${sessionToken}`);
});

// GET /api/session - Validate session
app.get('/api/session', (req, res) => {
  const { token } = req.query;
  if (!token || !verifiedUsers[token]) {
    return res.status(401).json({ valid: false });
  }
  const user = verifiedUsers[token];
  const entry = entries[user.email];
  res.json({
    valid: true,
    user: {
      email: user.email,
      firstName: entry?.firstName || '',
      lastName: entry?.lastName || '',
      entryId: user.entryId,
      phone: entry?.phone || ''
    }
  });
});

// POST /api/order - Place order
app.post('/api/order', async (req, res) => {
  try {
    const { sessionToken, selectedCar, deliveryDetails } = req.body;

    if (!sessionToken || !verifiedUsers[sessionToken]) {
      return res.status(401).json({ error: 'Invalid session. Please verify your email first.' });
    }

    const user = verifiedUsers[sessionToken];
    const orderId = 'TSLA-' + uuidv4().substring(0, 8).toUpperCase();
    const trackingNumber = 'TRK-' + crypto.randomBytes(4).toString('hex').toUpperCase();

    const order = {
      orderId,
      trackingNumber,
      email: user.email,
      entryId: user.entryId,
      selectedCar,
      deliveryDetails,
      status: 'confirmed',
      orderDate: new Date().toISOString(),
      estimatedDelivery: getEstimatedDelivery(),
      timeline: [
        { stage: 'Order Confirmed', timestamp: new Date().toISOString(), completed: true },
        { stage: 'Processing', timestamp: null, completed: false },
        { stage: 'Shipped', timestamp: null, completed: false },
        { stage: 'In Transit', timestamp: null, completed: false },
        { stage: 'Out for Delivery', timestamp: null, completed: false },
        { stage: 'Delivered', timestamp: null, completed: false }
      ]
    };

    orders[orderId] = order;

    // Send order confirmation email
    const mailOptions = {
      from: '"Tesla Giveaway" <techledger10@gmail.com>',
      to: user.email,
      subject: '🎉 Order Confirmed! Your Tesla is on the way!',
      html: getOrderConfirmationTemplate(order)
    };

    await transporter.sendMail(mailOptions);
    console.log(`✅ Order confirmation sent to ${user.email} (Order: ${orderId})`);

    res.json({
      success: true,
      order
    });

  } catch (error) {
    console.error('Order error:', error);
    res.status(500).json({ error: 'Server error. Please try again.' });
  }
});

// GET /api/order/:orderId - Track order
app.get('/api/order/:orderId', (req, res) => {
  const { orderId } = req.params;
  const order = orders[orderId];

  if (!order) {
    return res.status(404).json({ error: 'Order not found.' });
  }

  // Simulate progress based on time elapsed
  const orderWithProgress = simulateOrderProgress(order);
  res.json({ order: orderWithProgress });
});

// GET /api/order/tracking/:trackingNumber
app.get('/api/order/tracking/:trackingNumber', (req, res) => {
  const { trackingNumber } = req.params;
  const order = Object.values(orders).find(o => o.trackingNumber === trackingNumber);

  if (!order) {
    return res.status(404).json({ error: 'Tracking number not found.' });
  }

  const orderWithProgress = simulateOrderProgress(order);
  res.json({ order: orderWithProgress });
});

// ============ HELPERS ============

function getEstimatedDelivery() {
  const date = new Date();
  date.setDate(date.getDate() + 14); // 2 weeks estimated
  return date.toISOString().split('T')[0];
}

function simulateOrderProgress(order) {
  const now = new Date();
  const orderDate = new Date(order.orderDate);
  const hoursElapsed = (now - orderDate) / (1000 * 60 * 60);

  const updatedOrder = { ...order, timeline: [...order.timeline] };

  if (hoursElapsed > 1 && !updatedOrder.timeline[1].completed) {
    updatedOrder.timeline[1].completed = true;
    updatedOrder.timeline[1].timestamp = new Date(orderDate.getTime() + 1 * 60 * 60 * 1000).toISOString();
    updatedOrder.status = 'processing';
  }
  if (hoursElapsed > 24 && !updatedOrder.timeline[2].completed) {
    updatedOrder.timeline[2].completed = true;
    updatedOrder.timeline[2].timestamp = new Date(orderDate.getTime() + 24 * 60 * 60 * 1000).toISOString();
    updatedOrder.status = 'shipped';
  }
  if (hoursElapsed > 48 && !updatedOrder.timeline[3].completed) {
    updatedOrder.timeline[3].completed = true;
    updatedOrder.timeline[3].timestamp = new Date(orderDate.getTime() + 48 * 60 * 60 * 1000).toISOString();
    updatedOrder.status = 'in_transit';
  }
  if (hoursElapsed > 72 && !updatedOrder.timeline[4].completed) {
    updatedOrder.timeline[4].completed = true;
    updatedOrder.timeline[4].timestamp = new Date(orderDate.getTime() + 72 * 60 * 60 * 1000).toISOString();
    updatedOrder.status = 'out_for_delivery';
  }

  return updatedOrder;
}

// ============ EMAIL TEMPLATES ============

function getVerificationEmailTemplate(firstName, verifyLink, entryId) {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tesla Giveaway - Verify Your Email</title>
</head>
<body style="margin:0; padding:0; background-color:#000000; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#000000; padding:40px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background: linear-gradient(145deg, #0a0a0a 0%, #111111 100%); border:1px solid #222222; border-radius:16px; overflow:hidden; max-width:600px;">
          
          <!-- Header -->
          <tr>
            <td style="padding:40px 40px 20px; text-align:center;">
              <div style="display:inline-block;">
                <svg width="40" height="40" viewBox="0 0 100 100" style="vertical-align:middle;">
                  <path d="M50 5 L85 25 L85 75 L50 95 L15 75 L15 25 Z" fill="none" stroke="#E82127" stroke-width="4"/>
                  <text x="50" y="62" text-anchor="middle" fill="#E82127" font-size="28" font-weight="bold" font-family="sans-serif">T</text>
                </svg>
                <span style="color:#E82127; font-size:24px; font-weight:700; letter-spacing:2px; margin-left:8px; vertical-align:middle;">TESLA</span>
              </div>
            </td>
          </tr>

          <!-- Hero Strip -->
          <tr>
            <td style="background: linear-gradient(135deg, #1a0000 0%, #E82127 50%, #1a0000 100%); padding:3px;"></td>
          </tr>

          <!-- Main Content -->
          <tr>
            <td style="padding:40px;">
              <h1 style="color:#FFFFFF; font-size:28px; font-weight:600; margin:0 0 12px; text-align:center; line-height:1.3;">
                ⚡ Almost There, ${firstName}!
              </h1>
              <p style="color:#AAAAAA; font-size:16px; line-height:1.6; text-align:center; margin:0 0 30px;">
                You're one step away from potentially winning a brand new Tesla. Verify your email address to complete your entry.
              </p>

              <!-- Verify Button -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="${verifyLink}" style="display:inline-block; background: linear-gradient(135deg, #E82127, #ff3b3f); color:#FFFFFF; text-decoration:none; padding:16px 48px; border-radius:8px; font-size:18px; font-weight:700; letter-spacing:1px; text-transform:uppercase;">
                      Verify My Email
                    </a>
                  </td>
                </tr>
              </table>

              <p style="color:#666666; font-size:13px; text-align:center; margin:30px 0 0; line-height:1.6;">
                Or copy and paste this link:<br>
                <span style="color:#E82127; word-break:break-all;">${verifyLink}</span>
              </p>
            </td>
          </tr>

          <!-- Entry Details -->
          <tr>
            <td style="padding:0 40px 30px;">
              <table width="100%" cellpadding="0" cellspacing="0" style="background:#0d0d0d; border:1px solid #1a1a1a; border-radius:8px;">
                <tr>
                  <td style="padding:20px;">
                    <p style="color:#888888; font-size:12px; text-transform:uppercase; letter-spacing:1px; margin:0 0 8px;">Entry Details</p>
                    <p style="color:#CCCCCC; font-size:14px; margin:0;">
                      Entry ID: <span style="color:#FFFFFF; font-family:monospace;">${entryId}</span><br>
                      Status: <span style="color:#E82127;">Pending Verification</span>
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background:#0a0a0a; padding:30px 40px; border-top:1px solid #1a1a1a;">
              <p style="color:#555555; font-size:12px; text-align:center; margin:0; line-height:1.6;">
                This email was sent by Tesla Giveaway Promotion.<br>
                If you did not enter this giveaway, please ignore this email.<br><br>
                © 2026 Tesla Giveaway. All rights reserved.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

function getOrderConfirmationTemplate(order) {
  const carImages = {
    'model3': 'https://digitalassets.tesla.com/tesla-contents/image/upload/f_auto,q_auto/Mega-Menu-Vehicles-Model-3.png',
    'modely': 'https://digitalassets.tesla.com/tesla-contents/image/upload/f_auto,q_auto/Mega-Menu-Vehicles-Model-Y.png',
    'models': 'https://digitalassets.tesla.com/tesla-contents/image/upload/f_auto,q_auto/Mega-Menu-Vehicles-Model-S.png',
    'modelx': 'https://digitalassets.tesla.com/tesla-contents/image/upload/f_auto,q_auto/Mega-Menu-Vehicles-Model-X.png',
    'cybertruck': 'https://digitalassets.tesla.com/tesla-contents/image/upload/f_auto,q_auto/Mega-Menu-Vehicles-Cybertruck.png'
  };

  const car = order.selectedCar;
  const addr = order.deliveryDetails;

  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Confirmed - Tesla Giveaway</title>
</head>
<body style="margin:0; padding:0; background-color:#000000; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#000000; padding:40px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background: linear-gradient(145deg, #0a0a0a 0%, #111111 100%); border:1px solid #222222; border-radius:16px; overflow:hidden; max-width:600px;">
          
          <!-- Header -->
          <tr>
            <td style="padding:40px 40px 20px; text-align:center;">
              <span style="color:#E82127; font-size:24px; font-weight:700; letter-spacing:2px;">TESLA</span>
            </td>
          </tr>

          <!-- Success Banner -->
          <tr>
            <td style="background: linear-gradient(135deg, #003300 0%, #00cc44 50%, #003300 100%); padding:2px;"></td>
          </tr>

          <!-- Congratulations -->
          <tr>
            <td style="padding:40px 40px 20px; text-align:center;">
              <div style="font-size:64px; margin-bottom:12px;">🎉</div>
              <h1 style="color:#FFFFFF; font-size:28px; font-weight:600; margin:0 0 8px;">Order Confirmed!</h1>
              <p style="color:#00cc44; font-size:18px; margin:0;">Your Tesla order has been placed successfully</p>
            </td>
          </tr>

          <!-- Order Details -->
          <tr>
            <td style="padding:20px 40px;">
              <table width="100%" cellpadding="0" cellspacing="0" style="background:#0d0d0d; border:1px solid #1a1a1a; border-radius:8px;">
                <tr>
                  <td style="padding:24px;">
                    <p style="color:#888888; font-size:12px; text-transform:uppercase; letter-spacing:1px; margin:0 0 16px;">Order Summary</p>
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="padding:8px 0; color:#888888; font-size:14px;">Order ID</td>
                        <td style="padding:8px 0; color:#FFFFFF; font-size:14px; font-family:monospace; text-align:right;">${order.orderId}</td>
                      </tr>
                      <tr>
                        <td style="padding:8px 0; color:#888888; font-size:14px;">Tracking Number</td>
                        <td style="padding:8px 0; color:#E82127; font-size:14px; font-family:monospace; text-align:right;">${order.trackingNumber}</td>
                      </tr>
                      <tr>
                        <td style="padding:8px 0; color:#888888; font-size:14px;">Vehicle</td>
                        <td style="padding:8px 0; color:#FFFFFF; font-size:14px; text-align:right;">${car.name}</td>
                      </tr>
                      <tr>
                        <td style="padding:8px 0; color:#888888; font-size:14px;">Color</td>
                        <td style="padding:8px 0; color:#FFFFFF; font-size:14px; text-align:right;">${car.color}</td>
                      </tr>
                      <tr>
                        <td style="padding:8px 0; color:#888888; font-size:14px;">Est. Delivery</td>
                        <td style="padding:8px 0; color:#FFFFFF; font-size:14px; text-align:right;">${order.estimatedDelivery}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Delivery Address -->
          <tr>
            <td style="padding:10px 40px 30px;">
              <table width="100%" cellpadding="0" cellspacing="0" style="background:#0d0d0d; border:1px solid #1a1a1a; border-radius:8px;">
                <tr>
                  <td style="padding:24px;">
                    <p style="color:#888888; font-size:12px; text-transform:uppercase; letter-spacing:1px; margin:0 0 12px;">Delivery Address</p>
                    <p style="color:#CCCCCC; font-size:14px; margin:0; line-height:1.6;">
                      ${addr.fullName}<br>
                      ${addr.address}<br>
                      ${addr.city}, ${addr.state} ${addr.zipCode}<br>
                      ${addr.country}<br>
                      📞 ${addr.phone}
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- CTA -->
          <tr>
            <td style="padding:0 40px 30px; text-align:center;">
              <a href="#" style="display:inline-block; background:linear-gradient(135deg, #E82127, #ff3b3f); color:#FFFFFF; text-decoration:none; padding:14px 40px; border-radius:8px; font-size:16px; font-weight:700; letter-spacing:1px;">
                Track Your Order →
              </a>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background:#0a0a0a; padding:30px 40px; border-top:1px solid #1a1a1a;">
              <p style="color:#555555; font-size:12px; text-align:center; margin:0; line-height:1.6;">
                © 2026 Tesla Giveaway. All rights reserved.<br>
                This is a promotional giveaway. Terms and conditions apply.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

// ============ START SERVER ============
app.listen(PORT, () => {
  console.log(`⚡ Tesla Giveaway server running on http://localhost:${PORT}`);
});
